﻿import { createContext, useContext, ReactNode } from 'react';
import { useSalaryOptimization } from '../hooks/useSalaryOptimization';

type SalaryOptimizationContextType = ReturnType<typeof useSalaryOptimization>;

const TaxContext = createContext<SalaryOptimizationContextType | undefined>(undefined);

export const useTax = () => {
  const context = useContext(TaxContext);
  if (!context) {
    throw new Error('useTax must be used within a TaxProvider');
  }
  return context;
};

export const TaxProvider = ({ children }: { children: ReactNode }) => {
  const salaryOptimization = useSalaryOptimization();
  return (
    <TaxContext.Provider value={salaryOptimization}>
      {children}
    </TaxContext.Provider>
  );
};

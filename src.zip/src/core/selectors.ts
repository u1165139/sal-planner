﻿import { createSelector } from 'reselect';
import type { CalcInputs, CalcResults } from './types';

const selectResults = (results: CalcResults | null) => results;
const selectInputs = (inputs: CalcInputs) => inputs;

export const selectHeroSummary = createSelector(
  [selectResults, selectInputs],
  (results, inputs) => {
    if (!results) return null;
    return {
      recommendedSalary: results.recommendedSalary,
      superContribution: results.superContribution,
      netBusinessProfit: results.netBusinessProfit,
      businessRevenue: results.businessRevenue,
      maximiseSuper: inputs.maximiseSuper,
    };
  }
);

export const selectMetricsSummary = createSelector(
  [selectResults],
  (results) => {
    if (!results) return null;
    return {
      totalTax: results.totalTax,
      companyTax: results.companyTax,
      effectiveCompanyRate: results.effectiveCompanyRate,
      personalTaxTotal: results.personalTaxTotal,
      effectivePersonalRate: results.effectivePersonalRate,
      negativeGearingRefund: results.negativeGearingRefund,
      afterTaxSalary: results.afterTaxSalary,
    };
  }
);

export const selectCompanyTaxBreakdown = createSelector(
  [selectResults, selectInputs],
  (results, inputs) => {
    if (!results) return null;
    return {
      netBusinessProfit: results.netBusinessProfit,
      recommendedSalary: results.recommendedSalary,
      superContribution: results.superContribution,
      companyTaxableProfit: results.companyTaxableProfit,
      companyTax: results.companyTax,
      companyAfterTaxProfit: results.companyAfterTaxProfit,
      maximiseSuper: inputs.maximiseSuper,
    };
  }
);

export const selectPersonalTaxBreakdown = createSelector(
  [selectResults, selectInputs],
  (results, inputs) => {
    if (!results) return null;
    return {
      recommendedSalary: results.recommendedSalary,
      interestIncome: inputs.interestIncome,
      propertyIncome: inputs.propertyIncome,
      basePersonalTaxableIncome: results.basePersonalTaxableIncome,
      annualAdditionalPurchaseLoss: results.annualAdditionalPurchaseLoss,
      totalPersonalTaxableIncome: results.totalPersonalTaxableIncome,
      personalTaxTotal: results.personalTaxTotal,
      negativeGearingRefund: results.negativeGearingRefund,
      effectivePersonalRate: results.effectivePersonalRate,
    };
  }
);

export const selectCashFlowSummary = createSelector(
  [selectResults, selectInputs],
  (results, inputs) => {
    if (!results) return null;
    return {
      afterTaxSalary: results.afterTaxSalary,
      interestIncome: inputs.interestIncome,
      negativeGearingRefund: results.negativeGearingRefund,
      totalCashAvailable: results.totalCashAvailable,
      monthlyLiving: inputs.monthlyLiving,
      monthlyRepayments: inputs.monthlyRepayments,
      monthlyAdditionalPurchase: inputs.monthlyAdditionalPurchase,
      requiredAnnualCash: results.requiredAnnualCash,
      cashSurplusDeficit: results.cashSurplusDeficit,
    };
  }
);
